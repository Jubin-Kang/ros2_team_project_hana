import time

def arm_pick(item: str):
    print(f"[ARM] pick {item}")
    time.sleep(1)

def arm_place_on_robot():
    print("[ARM] place on robot")
    time.sleep(1)
