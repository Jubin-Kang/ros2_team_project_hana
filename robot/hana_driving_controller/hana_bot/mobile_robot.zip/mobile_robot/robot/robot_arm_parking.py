#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from geometry_msgs.msg import Twist
import socket
import cv2
import numpy as np
import threading
import queue
import struct


class LaneTracerUDP(Node):
    def __init__(self):
        super().__init__('udp_lane_tracer')

        # --- ROS2 퍼블리셔 ---
        self.deviation_pub = self.create_publisher(Float32, '/lane/deviation', 10)
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        # --- UDP 설정 ---
        self.udp_host = '224.1.1.1'
        self.udp_port = 5008
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(('', self.udp_port))
        mreq = struct.pack("4sl", socket.inet_aton(self.udp_host), socket.INADDR_ANY)
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
        self.get_logger().info(f"UDP 멀티캐스트 수신 대기 중: {self.udp_host}:{self.udp_port}")

        # --- 프레임 큐 ---
        self.frame_queue = queue.Queue(maxsize=2)
        threading.Thread(target=self._receive_frames, daemon=True).start()

        # --- HSV 값 (튜닝 결과 적용) ---
        self.lower_yellow = np.array([12, 0, 0])
        self.upper_yellow = np.array([41, 255, 255])

        # 색상 순서 변환 여부
        self.convert_rgb_to_bgr = True

        # --- 주행 파라미터 ---
        self.linear_speed = 0.1  # m/s
        self.angular_gain = 0.0005  # deviation → 회전속도 변환 비율

        # headless 모드 활성화 (GUI 비활성화)
        self.headless_mode = True

        # 주기적 처리
        self.create_timer(0.01, self.process_frame)  # 20Hz

    def _receive_frames(self):
        while rclpy.ok():
            try:
                data, _ = self.sock.recvfrom(65536)
                if not self.frame_queue.full():
                    self.frame_queue.put(data)
            except Exception as e:
                self.get_logger().error(f"UDP 수신 오류: {e}")

    def process_frame(self):
        try:
            data = self.frame_queue.get_nowait()
            while not self.frame_queue.empty():
                data = self.frame_queue.get_nowait()

            np_arr = np.frombuffer(data, np.uint8)
            frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
            if frame is None:
                return

            # 필요 시 RGB→BGR 변환
            if self.convert_rgb_to_bgr:
                frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)

            # HSV 변환 및 마스크 생성
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            mask = cv2.inRange(hsv, self.lower_yellow, self.upper_yellow)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))

            # 중심점 계산
            M = cv2.moments(mask)
            detected_area = M['m00']
            
            # 라인 검출 임계값 설정 (노이즈 필터링)
            min_line_area = 1000  # 최소 라인 면적 (픽셀)
            
            if detected_area > min_line_area:
                cx = int(M['m10'] / M['m00'])
                img_center = frame.shape[1] / 2
                deviation = cx - img_center

                # deviation 발행
                self.deviation_pub.publish(Float32(data=deviation))

                # cmd_vel 계산 및 발행
                twist = Twist()
                twist.linear.x = self.linear_speed
                twist.angular.z = -float(deviation) * self.angular_gain
                self.cmd_vel_pub.publish(twist)

                # 디버그용 출력 (더 상세한 정보 포함)
                self.get_logger().info(f"🟡 라인 감지: Area={detected_area:.0f}, Deviation={deviation:.2f}, Angular_Z={twist.angular.z:.3f}")

                # 중심점 표시
                if not self.headless_mode:
                    cv2.circle(frame, (cx, int(frame.shape[0] / 2)), 5, (0, 0, 255), -1)
            else:
                # 라인 미검출 시 정지
                twist = Twist()
                self.cmd_vel_pub.publish(twist)
                
                # 라인 미검출 로그 (너무 자주 출력되지 않도록 제한)
                if detected_area > 0:
                    self.get_logger().warn(f"⚪ 라인 미검출: Area={detected_area:.0f} < {min_line_area} (정지)")
                else:
                    self.get_logger().debug("⚫ 라인 완전 미검출 (정지)")

            # 화면 표시 (headless 모드에서는 완전히 비활성화)
            if not self.headless_mode:
                try:
                    cv2.imshow("UDP Lane View", frame)
                    cv2.imshow("UDP Lane Mask", mask)
                    if cv2.waitKey(1) & 0xFF == ord('q'):
                        rclpy.shutdown()
                except cv2.error as e:
                    self.get_logger().warn(f"OpenCV 디스플레이 오류: {e}")
            # headless 모드에서는 화면 표시 완전히 생략

        except queue.Empty:
            pass


def main():
    rclpy.init()
    node = LaneTracerUDP()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.sock.close()
        if not node.headless_mode:
            try:
                cv2.destroyAllWindows()
            except (cv2.error, AttributeError):
                # headless 환경에서는 창이 없으므로 무시
                pass
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
