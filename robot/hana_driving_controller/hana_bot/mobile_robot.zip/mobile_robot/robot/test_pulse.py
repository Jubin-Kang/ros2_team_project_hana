#!/usr/bin/env python3
# pulse_cmdvel_gui.py
# ROS2 rclpy + PyQt GUI로 cmd_vel 펄스 테스트 (초 단위: ON/Period)
import sys, time

# --- PyQt6 우선, 없으면 PyQt5 ---
try:
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QGridLayout, QLabel,
        QSlider, QDoubleSpinBox, QPushButton, QCheckBox, QHBoxLayout, QFrame
    )
    from PyQt6.QtCore import Qt, QTimer
    PYQT6 = True
except ImportError:
    from PyQt5.QtWidgets import (
        QApplication, QMainWindow, QWidget, QGridLayout, QLabel,
        QSlider, QDoubleSpinBox, QPushButton, QCheckBox, QHBoxLayout, QFrame
    )
    from PyQt5.QtCore import Qt, QTimer
    PYQT6 = False

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist


def hline():
    line = QFrame()
    line.setFrameShape(QFrame.Shape.HLine if PYQT6 else QFrame.HLine)
    line.setFrameShadow(QFrame.Shadow.Sunken if PYQT6 else QFrame.Sunken)
    return line


class PulseCmdVelGUI(QMainWindow):
    def __init__(self, topic_name='/cmd_vel', pub_rate_hz=50.0):
        super().__init__()
        self.setWindowTitle('cmd_vel Pulse Tester (seconds)')

        # ROS2
        self.node = Node('pulse_cmd_vel_gui')
        self.pub = self.node.create_publisher(Twist, topic_name, 10)

        # 상태값
        self.running = False
        self.t0 = None
        self.publish_period = 1.0 / pub_rate_hz

        # 기본 파라미터
        self.lin_speed = 0.05          # m/s
        self.ang_speed = 0.20          # rad/s
        self.pulse_on_s = 0.20         # seconds
        self.pulse_period_s = 0.30     # seconds
        self.lin_dir = +1              # +1 forward, -1 backward
        self.ang_dir = +1              # +1 CCW(+z), -1 CW(-z)
        self.enable_lin = True
        self.enable_ang = False

        # --- UI ---
        central = QWidget()
        grid = QGridLayout(central)
        grid.setContentsMargins(10, 10, 10, 10)
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(8)

        r = 0
        grid.addWidget(QLabel('Linear Speed (m/s)'), r, 0)
        self.layout_lin, self.sb_lin = self._make_slider_spin(0.0, 0.50, self.lin_speed, 0.005)
        grid.addLayout(self.layout_lin, r, 1)
        grid.addWidget(self.sb_lin, r, 2)

        r += 1
        grid.addWidget(QLabel('Angular Speed (rad/s)'), r, 0)
        self.layout_ang, self.sb_ang = self._make_slider_spin(0.0, 2.00, self.ang_speed, 0.01)
        grid.addLayout(self.layout_ang, r, 1)
        grid.addWidget(self.sb_ang, r, 2)

        r += 1
        grid.addWidget(hline(), r, 0, 1, 3)

        r += 1
        grid.addWidget(QLabel('Pulse ON (s)'), r, 0)
        self.layout_on, self.sb_on = self._make_slider_spin(0.01, 5.00, self.pulse_on_s, 0.01)
        grid.addLayout(self.layout_on, r, 1)
        grid.addWidget(self.sb_on, r, 2)

        r += 1
        grid.addWidget(QLabel('Pulse Period (s)'), r, 0)
        self.layout_per, self.sb_per = self._make_slider_spin(0.02, 10.00, self.pulse_period_s, 0.01)
        grid.addLayout(self.layout_per, r, 1)
        grid.addWidget(self.sb_per, r, 2)

        r += 1
        grid.addWidget(hline(), r, 0, 1, 3)

        # Enable & 방향
        r += 1
        box_lin = QHBoxLayout()
        self.cb_lin = QCheckBox('Enable Linear'); self.cb_lin.setChecked(self.enable_lin)
        self.cb_lin.stateChanged.connect(lambda s: setattr(self, 'enable_lin', s != 0))
        self.cb_lin_dir = QCheckBox('Forward (+)'); self.cb_lin_dir.setChecked(self.lin_dir > 0)
        self.cb_lin_dir.stateChanged.connect(lambda s: setattr(self, 'lin_dir', +1 if s != 0 else -1))
        box_lin.addWidget(self.cb_lin); box_lin.addWidget(self.cb_lin_dir); box_lin.addStretch(1)
        grid.addLayout(box_lin, r, 0, 1, 3)

        r += 1
        box_ang = QHBoxLayout()
        self.cb_ang = QCheckBox('Enable Angular'); self.cb_ang.setChecked(self.enable_ang)
        self.cb_ang.stateChanged.connect(lambda s: setattr(self, 'enable_ang', s != 0))
        self.cb_ang_dir = QCheckBox('CCW (+z)'); self.cb_ang_dir.setChecked(self.ang_dir > 0)
        self.cb_ang_dir.stateChanged.connect(lambda s: setattr(self, 'ang_dir', +1 if s != 0 else -1))
        box_ang.addWidget(self.cb_ang); box_ang.addWidget(self.cb_ang_dir); box_ang.addStretch(1)
        grid.addLayout(box_ang, r, 0, 1, 3)

        r += 1
        grid.addWidget(hline(), r, 0, 1, 3)

        # 버튼
        r += 1
        btns = QHBoxLayout()
        self.btn_start = QPushButton('START'); self.btn_start.clicked.connect(self.start)
        self.btn_stop  = QPushButton('STOP');  self.btn_stop.clicked.connect(self.stop)
        self.btn_zero  = QPushButton('Zero Now'); self.btn_zero.clicked.connect(self.zero_once)
        btns.addWidget(self.btn_start); btns.addWidget(self.btn_stop); btns.addWidget(self.btn_zero); btns.addStretch(1)
        grid.addLayout(btns, r, 0, 1, 3)

        # 상태 표시
        r += 1
        self.lbl_status = QLabel('Idle')
        grid.addWidget(self.lbl_status, r, 0, 1, 3)

        self.setCentralWidget(central)
        self.resize(560, 340)

        # 값 연결 (스핀박스 변경 시 내부 상태 갱신)
        self.sb_lin.valueChanged.connect(lambda v: setattr(self, 'lin_speed', float(v)))
        self.sb_ang.valueChanged.connect(lambda v: setattr(self, 'ang_speed', float(v)))
        self.sb_on.valueChanged.connect(self._set_on_s)
        self.sb_per.valueChanged.connect(self._set_period_s)

        # 퍼블리시 타이머
        self.timer = QTimer()
        self.timer.timeout.connect(self._on_tick)
        self.timer.start(int(self.publish_period * 1000))

    # ---------- UI helpers ----------
    def _make_slider_spin(self, vmin, vmax, v0, step):
        """
        슬라이더 <-> 스핀박스 양방향 동기화
        (버그 수정) 슬라이더→스핀(s2b)에서 blockSignals를 쓰지 않아
        스핀의 valueChanged가 정상적으로 발생하도록 함.
        """
        layout = QHBoxLayout()
        slider = QSlider(Qt.Orientation.Horizontal)
        scale = 1.0 / step
        decimals = 3 if step < 0.01 else 2

        slider.setMinimum(int(vmin * scale))
        slider.setMaximum(int(vmax * scale))
        slider.setValue(int(v0 * scale))
        slider.setSingleStep(1)
        slider.setPageStep(max(1, int(10 * scale)))
        layout.addWidget(slider)

        spin = QDoubleSpinBox()
        spin.setDecimals(decimals)
        spin.setMinimum(vmin)
        spin.setMaximum(vmax)
        spin.setSingleStep(step)
        spin.setValue(v0)
        spin.setKeyboardTracking(False)

        # 슬라이더 -> 스핀 (신호 막지 않음: 내부 상태 업데이트 핸들러가 불리도록)
        def s2b(val):
            spin.setValue(val / scale)

        # 스핀 -> 슬라이더 (루프 방지 위해 슬라이더 신호만 막음)
        def b2s(val):
            slider.blockSignals(True)
            slider.setValue(int(val * scale))
            slider.blockSignals(False)

        slider.valueChanged.connect(s2b)
        spin.valueChanged.connect(b2s)

        layout.addWidget(slider)
        return layout, spin

    # ---------- 파라미터 제약 ----------
    def _set_on_s(self, v):
        self.pulse_on_s = float(v)
        if self.pulse_on_s > self.pulse_period_s:
            self.pulse_period_s = self.pulse_on_s
            self.sb_per.blockSignals(True)
            self.sb_per.setValue(self.pulse_period_s)
            self.sb_per.blockSignals(False)

    def _set_period_s(self, v):
        self.pulse_period_s = float(v)
        if self.pulse_period_s < self.pulse_on_s:
            self.pulse_on_s = self.pulse_period_s
            self.sb_on.blockSignals(True)
            self.sb_on.setValue(self.pulse_on_s)
            self.sb_on.blockSignals(False)

    # ---------- 제어 ----------
    def start(self):
        self.running = True
        self.t0 = time.monotonic()
        self.lbl_status.setText('Running (pulse)')

    def stop(self):
        self.running = False
        self.zero_once()
        self.lbl_status.setText('Stopped')

    def zero_once(self):
        self.pub.publish(Twist())

    def _on_tick(self):
        if not self.running:
            return

        now = time.monotonic()
        if self.t0 is None:
            self.t0 = now

        period_s = max(0.001, float(self.pulse_period_s))
        on_s = max(0.0, min(period_s, float(self.pulse_on_s)))
        t_mod = (now - self.t0) % period_s
        on_window = (t_mod < on_s)

        lin = 0.0
        ang = 0.0
        if on_window:
            if self.enable_lin and self.lin_speed > 0.0:
                lin = self.lin_speed * (1.0 if self.lin_dir > 0 else -1.0)
            if self.enable_ang and self.ang_speed > 0.0:
                ang = self.ang_speed * (1.0 if self.ang_dir > 0 else -1.0)

        msg = Twist()
        msg.linear.x = float(lin)
        msg.angular.z = float(ang)
        self.pub.publish(msg)

        self.lbl_status.setText(
            f'Running | lin={lin:.3f} m/s | ang={ang:.3f} rad/s | '
            f'ON={self.pulse_on_s:.3f}s / Period={self.pulse_period_s:.3f}s'
        )

    def closeEvent(self, event):
        try:
            self.stop()
            for _ in range(3):
                self.zero_once()
                time.sleep(0.02)
        finally:
            self.node.destroy_publisher(self.pub)
            self.node.destroy_node()
        event.accept()


def main():
    rclpy.init()
    app = QApplication(sys.argv)
    win = PulseCmdVelGUI(topic_name='/cmd_vel', pub_rate_hz=50.0)
    win.show()
    try:
        rc = app.exec()
    finally:
        if rclpy.ok():
            rclpy.shutdown()
    sys.exit(rc)


if __name__ == '__main__':
    main()