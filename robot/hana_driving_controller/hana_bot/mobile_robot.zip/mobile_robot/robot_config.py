# Robot Configuration
# This file contains robot-specific settings that don't require database access
# Used for distributed deployment where robots run on separate machines

# ROS2 Topics
ROS_CMD_TOPIC   = "user_cmd"
ROS_STAT_TOPIC  = "status"

# Nav2 waypoints (rough approach positions)
PICKUP_ST1_NAV     = [0.25, -0.25, 0.0]  # Arm pickup station (Nav2 target)
SERVICE_ST1        = [0.1, 0.5, 0.707]     # Default service station (fallback)
CHARGING_ST_NAV    = [0.11, 0.28, 0.0]      # Charging dock (Nav2 target)

# Precision parking positions (fine-tuned final positions)
PICKUP_ST1_PARKING = [0.250, -0.245, 0.707,0.025, 0.015]  # Arm precise parking position
CHARGING_ST_PARKING = [-0.23, 0.05, -1.0, 0.020, 0.010]     # Dock precise parking position

# Service station parking configuration
SERVICE_PARKING_ENABLED = True       # Set True to enable precision parking at service stations
SERVICE_PARKING_YAW = -1.57          # Final orientation at service stations (radians)

# Room-specific parking coordinates with tolerances
# Key: location_name from DB, Value: [x, y, yaw, position_tolerance, angle_tolerance]
# If only [x, y, yaw] provided, default tolerances will be used
SERVICE_PARKING_COORDS = {
    "ROOM1": [-0.05, 0.75, 0.0, 0.030, 0.25],    # Room 1 with relaxed tolerances (3.0cm, ~5.7°)
    "ROOM2": [0.35, 0.75, 3.14, 0.030, 0.25],    # Room 2 with relaxed tolerances (3.0cm, ~5.7°)
    # Add more rooms as needed (must match location_name in DB exactly)
    # Format: [x, y, yaw] or [x, y, yaw, position_tolerance, angle_tolerance]
}

# Default parking tolerances (used when tolerances not specified in coords)
DEFAULT_POSITION_TOLERANCE = 0.015  # 1.5 cm
DEFAULT_ANGLE_TOLERANCE = 0.05      # ~2.9 degrees

# # Fallback: If room not in SERVICE_PARKING_COORDS, use offset
# SERVICE_PARKING_OFFSET = [0.0, 0.05]  # Default offset if room not configured

# Legacy names for backward compatibility
PICKUP_ST1 = PICKUP_ST1_NAV
CHARGING_ST = CHARGING_ST_NAV

# Fleet Manager connection (for distributed deployment)
FLEET_MANAGER_HOST = "localhost"  # Change this to Fleet Manager's IP
ROS_DOMAIN_ID = 0  # Set same domain ID across all machines

# Robot camera configuration (per robot)
ROBOT_CAMERA_PORT = 5009  # Default port, can be overridden per robot