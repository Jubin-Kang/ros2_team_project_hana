#!/usr/bin/env python3
"""
Round-trip test for parking.py with CSV logging
- Tests forward journey then return journey  
- Logs trip summary and position tracking at 0.1s intervals
"""

import rclpy
import math
import time
import csv
import os
from datetime import datetime
from robot.parking import AdvancedPositionController, ControllerState


class RoundTripTester:
    def __init__(self):
        # Test waypoints (forward and return)
        self.waypoints = [
            {"x": 0.24, "y": -0.23, "yaw": 1.57, "name": "Target"},  # Forward journey
            {"x": 0.0, "y": 0.0, "yaw": 0.0, "name": "Home"}         # Return journey
        ]
        
        # CSV files
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.trip_summary_file = f"trip_summary_{timestamp}.csv"
        self.position_tracking_file = f"position_tracking_{timestamp}.csv"
        
        # Tracking variables
        self.current_waypoint = 0
        self.trip_start_time = None
        self.last_tracking_time = None
        self.position_data = []
        
        # Controller
        self.controller = None
        
    def initialize_csv_files(self):
        """Initialize CSV files with headers"""
        # Trip summary CSV
        with open(self.trip_summary_file, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                'trip_number', 'direction', 'start_x', 'start_y', 'start_yaw', 
                'target_x', 'target_y', 'target_yaw', 'execution_time_sec',
                'final_x', 'final_y', 'final_yaw', 'position_error', 'angle_error'
            ])
            
        # Position tracking CSV  
        with open(self.position_tracking_file, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                'timestamp', 'trip_number', 'elapsed_time', 'x', 'y', 'yaw', 
                'target_x', 'target_y', 'target_yaw', 'distance_to_target',
                'controller_state', 'linear_cmd', 'angular_cmd'
            ])

    def log_trip_summary(self, trip_num, direction, start_pose, target, execution_time, final_pose):
        """Log trip summary to CSV"""
        position_error = math.hypot(target["x"] - final_pose["x"], target["y"] - final_pose["y"])
        angle_error = abs(self.wrap_angle(target["yaw"] - final_pose["yaw"]))
        
        with open(self.trip_summary_file, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                trip_num, direction,
                round(start_pose["x"], 4), round(start_pose["y"], 4), round(start_pose["yaw"], 4),
                round(target["x"], 4), round(target["y"], 4), round(target["yaw"], 4),
                round(execution_time, 2),
                round(final_pose["x"], 4), round(final_pose["y"], 4), round(final_pose["yaw"], 4),
                round(position_error, 4), round(angle_error, 4)
            ])

    def log_position_tracking(self, trip_num, elapsed_time):
        """Log current position at 0.1s intervals"""
        if self.controller is None or not self.controller.odom_received:
            return
            
        pose = self.controller.current_pose
        target = self.waypoints[self.current_waypoint]
        distance = pose.distance_to(target["x"], target["y"])
        
        # Get latest command velocity
        latest_data = self.controller.data
        linear_cmd = latest_data.linear_velocity_cmd[-1] if latest_data.linear_velocity_cmd else 0.0
        angular_cmd = latest_data.angular_velocity_cmd[-1] if latest_data.angular_velocity_cmd else 0.0
        
        with open(self.position_tracking_file, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                time.time(), trip_num, round(elapsed_time, 1),
                round(pose.x, 4), round(pose.y, 4), round(pose.theta, 4),
                round(target["x"], 4), round(target["y"], 4), round(target["yaw"], 4),
                round(distance, 4), self.controller.state.name,
                round(linear_cmd, 3), round(angular_cmd, 3)
            ])

    @staticmethod
    def wrap_angle(angle):
        """Normalize angle to [-pi, pi]"""
        return (angle + math.pi) % (2 * math.pi) - math.pi

    def wait_for_completion(self, trip_num):
        """Wait for controller to reach target and log position data"""
        print(f"🚀 Starting trip {trip_num} to {self.waypoints[self.current_waypoint]['name']}")
        
        self.trip_start_time = time.time()
        self.last_tracking_time = self.trip_start_time
        
        # Get initial pose
        while not self.controller.odom_received:
            rclpy.spin_once(self.controller, timeout_sec=0.1)
            time.sleep(0.01)
            
        start_pose = {
            "x": self.controller.current_pose.x,
            "y": self.controller.current_pose.y, 
            "yaw": self.controller.current_pose.theta
        }
        
        # Wait for completion while logging position data
        while rclpy.ok():
            rclpy.spin_once(self.controller, timeout_sec=0.01)
            
            current_time = time.time()
            elapsed = current_time - self.trip_start_time
            
            # Log position every 0.1 seconds
            if current_time - self.last_tracking_time >= 0.1:
                self.log_position_tracking(trip_num, elapsed)
                self.last_tracking_time = current_time
                
            # Check completion
            if self.controller.state == ControllerState.REACHED:
                execution_time = elapsed
                final_pose = {
                    "x": self.controller.current_pose.x,
                    "y": self.controller.current_pose.y,
                    "yaw": self.controller.current_pose.theta
                }
                
                direction = "Forward" if trip_num == 1 else "Return"
                target = self.waypoints[self.current_waypoint]
                
                self.log_trip_summary(trip_num, direction, start_pose, target, execution_time, final_pose)
                
                print(f"✅ Trip {trip_num} completed in {execution_time:.2f}s")
                print(f"📍 Final position: ({final_pose['x']:.4f}, {final_pose['y']:.4f}, {math.degrees(final_pose['yaw']):.1f}°)")
                break
                
            elif self.controller.state == ControllerState.ERROR:
                print(f"❌ Trip {trip_num} failed with error")
                break
                
            # Timeout after 60 seconds
            if elapsed > 60:
                print(f"⏰ Trip {trip_num} timed out after 60s")
                break
                
            time.sleep(0.01)

    def run_round_trip_test(self):
        """Execute the complete round-trip test"""
        print("🎯 Starting round-trip test")
        
        # Initialize CSV files
        self.initialize_csv_files()
        print(f"📊 CSV files created: {self.trip_summary_file}, {self.position_tracking_file}")
        
        # Initialize ROS2 and controller
        rclpy.init()
        self.controller = AdvancedPositionController()
        
        try:
            # Wait for initial odometry
            print("⏳ Waiting for odometry...")
            while not self.controller.odom_received and rclpy.ok():
                rclpy.spin_once(self.controller, timeout_sec=0.1)
                time.sleep(0.1)
                
            print("📡 Odometry received, starting test")
            
            # Execute both trips
            for trip_num in range(1, 3):  # Trip 1: Forward, Trip 2: Return
                waypoint = self.waypoints[self.current_waypoint]
                
                # Set target for this trip
                self.controller.set_target(
                    waypoint["x"], waypoint["y"], waypoint["yaw"],
                    position_tolerance=0.015,  # 1.5cm
                    angle_tolerance=0.05       # ~3°
                )
                
                # Wait for completion and log data
                self.wait_for_completion(trip_num)
                
                # Move to next waypoint
                self.current_waypoint = (self.current_waypoint + 1) % len(self.waypoints)
                
                # Brief pause between trips
                if trip_num < 2:
                    print("⏸️  3 second pause before return trip...")
                    time.sleep(3)
                    
            print("🎉 Round-trip test completed!")
            print(f"📊 Results saved to: {self.trip_summary_file}, {self.position_tracking_file}")
            
        except KeyboardInterrupt:
            print("🛑 Test interrupted by user")
        finally:
            if self.controller:
                self.controller.stop_robot()
                self.controller.destroy_node()
            rclpy.shutdown()


def main():
    tester = RoundTripTester()
    tester.run_round_trip_test()


if __name__ == '__main__':
    main()