# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a ROS2-based robot position controller testing framework for autonomous mobile robot parking experiments. The system implements advanced PID control with state machine logic for precise positioning and orientation control.

## Core Architecture

### Main Components

- **AdvancedPositionController**: Multi-state ROS2 node implementing sophisticated position control
  - State machine: IDLE → ROTATING_TO_TARGET → MOVING_TO_TARGET → FINAL_ADJUSTMENT → REAPPROACH → REACHED
  - Enhanced PID controllers for linear and angular motion
  - Pulse control for fine positioning adjustments
  - Comprehensive data collection and metrics

- **DataCollector**: Real-time telemetry system capturing pose, velocities, errors, and control outputs
- **Trial System**: Automated experiment execution with A/B leg support (outbound/return trips)

### Control Flow

1. **Initial Rotation**: Coarse alignment toward target before movement
2. **Approach Phase**: Combined linear movement with minor angular corrections
3. **Final Adjustment**: Rotation-only phase for precise yaw alignment
4. **Reapproach**: Mini-loop system alternating between rotation and linear pulse steps
5. **Validation**: Hold position verification before declaring success

## Development Commands

### Single Trial Execution
```bash
# Basic parking test
python3 run_trial.py --goal_x 0.24 --goal_y -0.23 --goal_yaw_deg 90

# Round-trip test (A→B→A)
python3 run_trial.py --goal_x 0.24 --goal_y -0.23 --goal_yaw_deg 90 --round_trip

# Custom tolerances and timeout
python3 run_trial.py --goal_x 0.5 --goal_y 0.0 --goal_yaw_deg 0 --timeout_s 60
```

### Batch Testing
```bash
# Run multiple sequential trials
python3 batch_trials.py --start_n 1 --end_n 5 \
  --goal_x 0.24 --goal_y -0.23 --goal_yaw_deg 90 \
  --round_trip --sleep_s 3
```

### ROS2 Operations
```bash
# Launch individual controller (for development)
ros2 run . advanced_position_controller.py

# Monitor topics
ros2 topic echo /DP_08/odom_aruco  # odometry input
ros2 topic echo /cmd_vel           # velocity commands

# Parameter adjustment
ros2 param set /advanced_position_controller_headless target_x 0.5
```

## Data Output Structure

### Generated Files Per Trial
- `trial_XXX_YYYYMMDD_HHMMSS_A_timeseries_10hz.csv`: High-frequency pose and control data
- `trial_XXX_YYYYMMDD_HHMMSS_A_events.csv`: State transitions and discrete events
- `trial_XXX_YYYYMMDD_HHMMSS_B_*.csv`: Return leg data (if round-trip enabled)
- `trials_summary.csv`: Aggregated performance metrics across all trials

### Key Metrics Tracked
- Position/angular errors (max, RMS)
- Path efficiency and oscillation count
- Control effort and peak velocities
- State transition timing
- Success/failure classification

## Important ROS2 Topics

- **Input**: `/DP_08/odom_aruco` (nav_msgs/Odometry) - Robot pose feedback
- **Output**: `/cmd_vel` (geometry_msgs/Twist) - Velocity commands

## Parameter Tuning Areas

### PID Controllers (advanced_position_controller.py:294-300)
- Angular PID: kp=2.0, ki=0.1, kd=0.5 for rotation control
- Linear PID: kp=1.0, ki=0.05, kd=0.2 for translation control

### Tolerance Settings (advanced_position_controller.py:238-241)
- Position tolerance: 0.015m (15mm precision)
- Angle tolerance: 0.05 rad (~2.9°)

### Pulse Control Parameters (advanced_position_controller.py:244-276)
- Fine-tuning for final positioning adjustments
- Separate linear and angular pulse configurations

## Testing Patterns

- Single-point accuracy tests with various goal positions
- Round-trip consistency validation
- Batch testing for statistical performance analysis
- Parameter sensitivity analysis through systematic variation

## Development Notes

- Uses ArUco marker-based odometry for precise positioning feedback
- Implements deadband logic to prevent excessive micro-corrections
- State machine includes recovery mechanisms for challenging positioning scenarios
- Comprehensive event logging enables post-trial analysis and debugging