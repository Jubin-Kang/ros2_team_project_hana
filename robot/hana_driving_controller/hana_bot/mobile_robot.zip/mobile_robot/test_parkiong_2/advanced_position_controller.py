# ================================
# File: advanced_position_controller.py
# ================================

import math
import numpy as np
from typing import Dict
from dataclasses import dataclass, field
from enum import Enum
from collections import deque

# ROS2
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist


class ControllerState(Enum):
    IDLE = 0
    ROTATING_TO_TARGET = 1
    MOVING_TO_TARGET = 2
    FINAL_ADJUSTMENT = 3
    PULSE_CONTROL = 4
    REACHED = 5
    ERROR = 6
    PAUSED = 7
    REAPPROACH = 8  # ★ 최종 회전 완료 후, 거리가 크면 미니 루프(짧게 회전→짧게 전/후진)


@dataclass
class PIDGains:
    kp: float = 0.0
    ki: float = 0.0
    kd: float = 0.0
    integral_limit: float = 1.0
    output_limit: float = 1.0
    # debug tracking
    p_term: float = field(default=0.0, init=False)
    i_term: float = field(default=0.0, init=False)
    d_term: float = field(default=0.0, init=False)
    total_output: float = field(default=0.0, init=False)


@dataclass
class RobotPose:
    x: float = 0.0
    y: float = 0.0
    theta: float = 0.0
    vx: float = field(default=0.0, init=False)
    vy: float = field(default=0.0, init=False)
    omega: float = field(default=0.0, init=False)

    def distance_to(self, tx: float, ty: float) -> float:
        return math.hypot(tx - self.x, ty - self.y)

    def angle_to(self, tx: float, ty: float) -> float:
        return math.atan2(ty - self.y, tx - self.x)


@dataclass
class PerformanceMetrics:
    start_time: float = 0.0
    total_time: float = 0.0
    settling_time: float = 0.0
    max_position_error: float = 0.0
    max_angular_error: float = 0.0
    rms_position_error: float = 0.0
    rms_angular_error: float = 0.0
    overshoot_count: int = 0
    oscillation_count: int = 0
    average_speed: float = 0.0
    distance_traveled: float = 0.0
    total_control_effort: float = 0.0
    peak_linear_velocity: float = 0.0
    peak_angular_velocity: float = 0.0


class EnhancedPIDController:
    def __init__(self, gains: PIDGains, name: str = "PID"):
        self.gains = gains
        self.name = name
        self.integral = 0.0
        self.prev_error = 0.0
        self.prev_time = None
        self.error_history = deque(maxlen=1000)
        self.output_history = deque(maxlen=1000)
        self.derivative_history = deque(maxlen=100)
        self.peak_error = 0.0
        self.settling_criteria = 0.02
        self.settled_time = None
        self.oscillation_count = 0
        self.last_error_sign = 0

    def reset(self):
        self.integral = 0.0
        self.prev_error = 0.0
        self.prev_time = None
        self.error_history.clear()
        self.output_history.clear()
        self.derivative_history.clear()
        self.peak_error = 0.0
        self.settled_time = None
        self.oscillation_count = 0
        self.last_error_sign = 0

    def compute(self, error: float, now: float) -> float:
        self.error_history.append((now, error))
        self.peak_error = max(self.peak_error, abs(error))
        s = np.sign(error)
        if self.last_error_sign != 0 and s != self.last_error_sign:
            self.oscillation_count += 1
        self.last_error_sign = s

        if abs(error) < self.settling_criteria and self.settled_time is None:
            self.settled_time = now
        elif abs(error) >= self.settling_criteria:
            self.settled_time = None

        if self.prev_time is None:
            self.prev_time = now
            self.prev_error = error
            out = self.gains.kp * error
            self.gains.p_term, self.gains.i_term, self.gains.d_term = out, 0.0, 0.0
            self.gains.total_output = out
            return out

        dt = now - self.prev_time
        if dt <= 0:
            return self.gains.kp * error

        self.gains.p_term = self.gains.kp * error
        self.integral += error * dt
        self.integral = float(np.clip(self.integral, -self.gains.integral_limit, self.gains.integral_limit))
        self.gains.i_term = self.gains.ki * self.integral

        d = (error - self.prev_error) / dt
        self.derivative_history.append(d)
        if len(self.derivative_history) > 5:
            d = float(np.mean(list(self.derivative_history)[-5:]))
        self.gains.d_term = self.gains.kd * d

        out = self.gains.p_term + self.gains.i_term + self.gains.d_term
        out = float(np.clip(out, -self.gains.output_limit, self.gains.output_limit))
        self.gains.total_output = out

        self.prev_error = error
        self.prev_time = now
        return out


class DataCollector:
    def __init__(self, max_samples: int = 5000):
        self.timestamps = deque(maxlen=max_samples)
        self.position_x = deque(maxlen=max_samples)
        self.position_y = deque(maxlen=max_samples)
        self.theta = deque(maxlen=max_samples)
        self.vx = deque(maxlen=max_samples)
        self.omega = deque(maxlen=max_samples)
        self.position_error = deque(maxlen=max_samples)
        self.angular_error = deque(maxlen=max_samples)
        self.distance_to_target = deque(maxlen=max_samples)
        self.linear_velocity_cmd = deque(maxlen=max_samples)
        self.angular_velocity_cmd = deque(maxlen=max_samples)
        self.controller_state = deque(maxlen=max_samples)
        self.planned_reverse = deque(maxlen=max_samples)
        self.linear_pid_p = deque(maxlen=max_samples)
        self.linear_pid_i = deque(maxlen=max_samples)
        self.linear_pid_d = deque(maxlen=max_samples)
        self.angular_pid_p = deque(maxlen=max_samples)
        self.angular_pid_i = deque(maxlen=max_samples)
        self.angular_pid_d = deque(maxlen=max_samples)

    def add_sample(self, t: float, pose: RobotPose, tx: float, ty: float,
                   ang_err: float, cmd: Twist, state: ControllerState,
                   lin_pid: EnhancedPIDController, ang_pid: EnhancedPIDController,
                   planned_reverse: bool):
        self.timestamps.append(t)
        self.position_x.append(pose.x)
        self.position_y.append(pose.y)
        self.theta.append(pose.theta)
        self.vx.append(pose.vx)
        self.omega.append(pose.omega)
        dist = pose.distance_to(tx, ty)
        self.position_error.append(dist)
        self.angular_error.append(ang_err)
        self.distance_to_target.append(dist)
        self.linear_velocity_cmd.append(cmd.linear.x)
        self.angular_velocity_cmd.append(cmd.angular.z)
        self.controller_state.append(state.value)
        self.planned_reverse.append(1 if planned_reverse else 0)
        self.linear_pid_p.append(lin_pid.gains.p_term)
        self.linear_pid_i.append(lin_pid.gains.i_term)
        self.linear_pid_d.append(lin_pid.gains.d_term)
        self.angular_pid_p.append(ang_pid.gains.p_term)
        self.angular_pid_i.append(ang_pid.gains.i_term)
        self.angular_pid_d.append(ang_pid.gains.d_term)

    def get_arrays(self) -> Dict[str, np.ndarray]:
        return {
            'timestamps': np.array(self.timestamps),
            'position_x': np.array(self.position_x),
            'position_y': np.array(self.position_y),
            'theta': np.array(self.theta),
            'vx': np.array(self.vx),
            'omega': np.array(self.omega),
            'position_error': np.array(self.position_error),
            'angular_error': np.array(self.angular_error),
            'distance_to_target': np.array(self.distance_to_target),
            'linear_velocity_cmd': np.array(self.linear_velocity_cmd),
            'angular_velocity_cmd': np.array(self.angular_velocity_cmd),
            'controller_state': np.array(self.controller_state),
            'planned_reverse': np.array(self.planned_reverse),
            'linear_pid_p': np.array(self.linear_pid_p),
            'linear_pid_i': np.array(self.linear_pid_i),
            'linear_pid_d': np.array(self.linear_pid_d),
            'angular_pid_p': np.array(self.angular_pid_p),
            'angular_pid_i': np.array(self.angular_pid_i),
            'angular_pid_d': np.array(self.angular_pid_d),
        }


class AdvancedPositionController(Node):
    def __init__(self):
        super().__init__('advanced_position_controller_headless')

        # ── Target & yaw ──
        self.declare_parameter('target_x', 0.24)
        self.declare_parameter('target_y', -0.23)
        self.declare_parameter('target_yaw', 1.57)  # rad
        
        self.target_x = float(self.get_parameter('target_x').value)
        self.target_y = float(self.get_parameter('target_y').value)
        self.target_yaw = float(self.get_parameter('target_yaw').value)

        # ── Tolerances ──
        self.declare_parameter('position_tolerance', 0.015)
        self.declare_parameter('angle_tolerance', 0.05)      # ~2.9°
        self.position_tolerance = float(self.get_parameter('position_tolerance').value)
        self.angle_tolerance = float(self.get_parameter('angle_tolerance').value)

        # ── Generic pulse (near target) ──
        self.declare_parameter('pulse_activation_distance', 0.05)
        self.declare_parameter('pulse_duration', 0.2)
        self.declare_parameter('pulse_interval', 0.3)
        self.declare_parameter('pulse_linear_speed', 0.02)
        self.declare_parameter('pulse_angular_speed', 0.2)
        self.pulse_activation_distance = float(self.get_parameter('pulse_activation_distance').value)
        self.pulse_duration = float(self.get_parameter('pulse_duration').value)
        self.pulse_interval = float(self.get_parameter('pulse_interval').value)
        self.pulse_linear_speed = float(self.get_parameter('pulse_linear_speed').value)
        self.pulse_angular_speed = float(self.get_parameter('pulse_angular_speed').value)

        # ── FINAL_ADJUSTMENT: linear pulse (미세 전/후진) ──
        self.declare_parameter('final_lin_pulse_duration', 0.10)
        self.declare_parameter('final_lin_pulse_interval', 0.22)
        self.declare_parameter('final_lin_pulse_speed', 0.5)
        self.declare_parameter('final_forward_deadband', 0.008)  # 8 mm
        self.declare_parameter('reach_hold_time', 0.25)          # hold to confirm reach
        self.final_lin_pulse_duration = float(self.get_parameter('final_lin_pulse_duration').value)
        self.final_lin_pulse_interval = float(self.get_parameter('final_lin_pulse_interval').value)
        self.final_lin_pulse_speed = float(self.get_parameter('final_lin_pulse_speed').value)
        self.final_forward_deadband = float(self.get_parameter('final_forward_deadband').value)
        self.reach_hold_time = float(self.get_parameter('reach_hold_time').value)

        # ── FINAL_ADJUSTMENT: angular pulse (fixed speed, FIXED ON/OFF) ──
        self.declare_parameter('fa_ang_speed', 0.40)            # rad/s (fixed)
        self.declare_parameter('fa_ang_on', 0.08)                # ON duration [s]
        self.declare_parameter('fa_ang_off', 0.18)               # OFF duration [s]
        self.declare_parameter('fa_ang_deadband_deg', 3.0)      # skip if below
        self.fa_ang_speed = float(self.get_parameter('fa_ang_speed').value)
        self.fa_ang_on = float(self.get_parameter('fa_ang_on').value)
        self.fa_ang_off = float(self.get_parameter('fa_ang_off').value)
        self.fa_ang_deadband = math.radians(float(self.get_parameter('fa_ang_deadband_deg').value))

        # ── Reapproach mini-loop 파라미터 ──
        self.declare_parameter('step_ang_tol_deg', 2.0)         # ROTATE 종료 기준
        self.declare_parameter('step_ang_deadband_deg', 1.0)    # 아주 작으면 펄스 생략
        self.declare_parameter('yaw_lock_deg_exit', 6.0)        # STEP 중 yaw 흐트러지면 ROTATE 복귀
        self.step_ang_tol = math.radians(float(self.get_parameter('step_ang_tol_deg').value))
        self.step_ang_deadband = math.radians(float(self.get_parameter('step_ang_deadband_deg').value))
        self.yaw_lock_exit = math.radians(float(self.get_parameter('yaw_lock_deg_exit').value))

        # ── (옵션) REAPPROACH 전/후 방향 표기용 ──
        self._planned_reverse = False

        # ── Limits ──
        self.declare_parameter('max_linear_vel', 0.2)
        self.declare_parameter('max_angular_vel', 0.5)
        self.max_linear_vel = float(self.get_parameter('max_linear_vel').value)
        self.max_angular_vel = float(self.get_parameter('max_angular_vel').value)

        # ── PID ──
        self.angular_pid = EnhancedPIDController(PIDGains(
            kp=2.0, ki=0.1, kd=0.5, integral_limit=0.5, output_limit=self.max_angular_vel
        ), "Angular")
        self.linear_pid = EnhancedPIDController(PIDGains(
            kp=1.0, ki=0.05, kd=0.2, integral_limit=0.3, output_limit=self.max_linear_vel
        ), "Linear")

        # ── State ──
        self.current_pose = RobotPose()
        self.state = ControllerState.IDLE
        self.odom_received = False

        # ── Telemetry ──
        self.metrics = PerformanceMetrics()
        self.data = DataCollector()

        # ── Pulse/phase state ──
        self.pulse_cycle_start_time = None
        self._lin_pulse_t0 = None
        self._reach_since = None
        self.fa_pulse_t0 = None
        self.fa_current_on = self.fa_ang_on
        self.fa_current_interval = self.fa_ang_on + self.fa_ang_off
        self.re_phase = 'ROTATE'  # 'ROTATE' -> 'STEP'

        # ── ROS I/O (고정 토픽) ──
        self.odom_sub = self.create_subscription(Odometry, '/DP_08/odom_aruco', self.odom_callback, qos_profile_sensor_data)
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        # ── Timers ──
        self.control_timer = self.create_timer(0.02, self.control_loop)  # 50Hz
        self.status_timer = self.create_timer(1.0, self.print_status)

        # ── Timeout ──
        self.start_time_ros = self.get_clock().now()
        self.timeout_duration = 100000.0

        # ── Event logging ──
        self._last_state = self.state
        self._events = []  # list of dicts: {t, type, from, to, x,y,theta, dist, ang_err}

        self.get_logger().info('🚀 Controller initialized')
        self.get_logger().info(f'Target: ({self.target_x:.3f}, {self.target_y:.3f}), yaw={math.degrees(self.target_yaw):.1f}°')
        self.get_logger().info('Topics: odom="/DP_09/odom_aruco", cmd_vel="/cmd_vel"')

    # ----------------- utils -----------------

    @staticmethod
    def yaw_from_quat(q) -> float:
        siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        return math.atan2(siny_cosp, cosy_cosp)

    @staticmethod
    def wrap_angle(a: float) -> float:
        return (a + math.pi) % (2 * math.pi) - math.pi

    def shortest_ang_dist(self, a: float, b: float) -> float:
        a = self.wrap_angle(a)
        b = self.wrap_angle(b)
        d = b - a
        if d > math.pi:
            d -= 2 * math.pi
        elif d < -math.pi:
            d += 2 * math.pi
        return d

    # ----------------- PUBLIC API -----------------

    def set_target(self, x: float, y: float, target_yaw: float,
                   position_tolerance: float = None, angle_tolerance: float = None):
        self.target_x = float(x)
        self.target_y = float(y)
        self.target_yaw = float(target_yaw)

        if position_tolerance is not None:
            self.position_tolerance = float(position_tolerance)
        if angle_tolerance is not None:
            self.angle_tolerance = float(angle_tolerance)

        # 안전 리셋
        self.angular_pid.reset()
        self.linear_pid.reset()
        self._lin_pulse_t0 = None
        self.pulse_cycle_start_time = None
        self.fa_pulse_t0 = None
        self._reach_since = None
        self._planned_reverse = False
        self.re_phase = 'ROTATE'

        prev = self.state
        self.state = ControllerState.ROTATING_TO_TARGET if self.odom_received else ControllerState.IDLE
        self.stop_robot()

        tolerance_info = ""
        if position_tolerance is not None or angle_tolerance is not None:
            tolerance_info = f" | pos_tol={self.position_tolerance:.3f}m, ang_tol={math.degrees(self.angle_tolerance):.1f}°"
        self.get_logger().info(
            f"🎯 New target set → ({self.target_x:.3f}, {self.target_y:.3f}), "
            f"yaw={math.degrees(self.target_yaw):.1f}° | state {prev.name} → {self.state.name}{tolerance_info}"
        )

    # ----------------- FA angular pulse (FIXED ON/OFF) -----------------

    def fa_ang_pulse_active(self, now: float) -> bool:
        """고정 ON/OFF 각도 펄스: ON=fa_ang_on, OFF=fa_ang_off"""
        if self.fa_pulse_t0 is None:
            self.fa_pulse_t0 = now
            self.fa_current_on = self.fa_ang_on
            self.fa_current_interval = self.fa_ang_on + self.fa_ang_off
            return True

        el = now - self.fa_pulse_t0
        cycle = self.fa_current_interval
        if el >= cycle:
            self.fa_pulse_t0 = now
            self.fa_current_on = self.fa_ang_on
            self.fa_current_interval = self.fa_ang_on + self.fa_ang_off
            el = 0.0
        return el < self.fa_current_on

    # ----------------- generic pulses -----------------

    def _lin_pulse_active(self, now: float) -> bool:
        if self._lin_pulse_t0 is None:
            self._lin_pulse_t0 = now
            return True
        el = now - self._lin_pulse_t0
        if el >= self.final_lin_pulse_interval:
            self._lin_pulse_t0 = now
            el = 0.0
        return el < self.final_lin_pulse_duration

    def _ang_pulse_active_generic(self, now: float) -> bool:
        if self.pulse_cycle_start_time is None:
            self.pulse_cycle_start_time = now
            return True
        el = now - self.pulse_cycle_start_time
        if el >= self.pulse_interval:
            self.pulse_cycle_start_time = now
            el = 0.0
        return el < self.pulse_duration

    # ----------------- events -----------------

    def _log_event(self, etype: str, from_state: str = "", to_state: str = ""):
        now = self.get_clock().now().nanoseconds / 1e9
        dist_now = self.current_pose.distance_to(self.target_x, self.target_y)
        to_target_now = self.current_pose.angle_to(self.target_x, self.target_y)
        ang_err_now = self.wrap_angle(to_target_now - self.current_pose.theta)
        self._events.append({
            't': now,
            'type': etype,
            'from': from_state,
            'to': to_state,
            'x': self.current_pose.x,
            'y': self.current_pose.y,
            'theta': self.current_pose.theta,
            'dist': dist_now,
            'ang_err': ang_err_now
        })

    # ----------------- callbacks -----------------

    def odom_callback(self, msg: Odometry):
        if not self.odom_received and self.state == ControllerState.IDLE:
            self.state = ControllerState.ROTATING_TO_TARGET
            self.metrics.start_time = self.get_clock().now().nanoseconds / 1e9
            self._log_event('STATE_CHANGE', 'IDLE', 'ROTATING_TO_TARGET')
            self._last_state = self.state
            self.get_logger().info('🎯 Starting navigation...')

        self.odom_received = True
        self.current_pose.x = msg.pose.pose.position.x
        self.current_pose.y = msg.pose.pose.position.y
        self.current_pose.theta = self.yaw_from_quat(msg.pose.pose.orientation)
        self.current_pose.vx = msg.twist.twist.linear.x
        self.current_pose.omega = msg.twist.twist.angular.z

    # ----------------- control -----------------

    def control_loop(self):
        if not self.odom_received:
            return

        elapsed = (self.get_clock().now() - self.start_time_ros).nanoseconds / 1e9
        if elapsed > self.timeout_duration and self.state != ControllerState.REACHED:
            self.get_logger().error(f'⏰ Timeout! Failed to reach target in {self.timeout_duration}s')
            self._log_event('TIMEOUT', self.state.name, 'ERROR')
            self.state = ControllerState.ERROR
            self.stop_robot()
            return

        now = self.get_clock().now().nanoseconds / 1e9
        cmd = Twist()

        dist = self.current_pose.distance_to(self.target_x, self.target_y)
        to_target = self.current_pose.angle_to(self.target_x, self.target_y)
        alpha = self.wrap_angle(to_target - self.current_pose.theta)  # ref only

        # metrics
        self.metrics.max_position_error = max(self.metrics.max_position_error, dist)
        self.metrics.max_angular_error = max(self.metrics.max_angular_error, abs(alpha))

        if self.state == ControllerState.ROTATING_TO_TARGET:
            # coarse 회전 (초기 정렬 - 이동 전)
            if abs(alpha) > self.angle_tolerance:
                cmd.angular.z = self.angular_pid.compute(alpha, now)
            else:
                self.get_logger().info('✅ Rotation complete → MOVING_TO_TARGET')
                self.state = ControllerState.MOVING_TO_TARGET
                self.angular_pid.reset()
                self.linear_pid.reset()

        elif self.state == ControllerState.MOVING_TO_TARGET:
            # 일반 접근 구간: 이동+약한 회전 허용 (원래 로직 유지)
            if dist > self.position_tolerance:
                dx, dy = self.target_x - self.current_pose.x, self.target_y - self.current_pose.y
                ct, st = math.cos(self.current_pose.theta), math.sin(self.current_pose.theta)
                ex = dx * ct + dy * st  # forward component
                cmd.linear.x = self.linear_pid.compute(ex, now)
                if abs(ex) < 0.1:
                    cmd.linear.x *= 0.5
                if abs(alpha) > self.angle_tolerance * 2:
                    cmd.angular.z = self.angular_pid.compute(alpha, now) * 0.5
            else:
                # 근접하면 최종 단계로: 여기서부터는 분리 로직
                self.get_logger().info('🎯 Near target → FINAL_ADJUSTMENT (rotate-only)')
                self.state = ControllerState.FINAL_ADJUSTMENT
                self.angular_pid.reset()
                self.linear_pid.reset()
                self._lin_pulse_t0 = None
                self.pulse_cycle_start_time = None
                self._reach_since = None
                self.fa_pulse_t0 = None
                self.re_phase = 'ROTATE'

        elif self.state == ControllerState.PULSE_CONTROL:
            # (선택기능) 사용 안 하면 넘어가도 됨
            if dist > self.position_tolerance:
                if self._ang_pulse_active_generic(now):
                    dx, dy = self.target_x - self.current_pose.x, self.target_y - self.current_pose.y
                    dn = math.hypot(dx, dy)
                    if dn > 0.0:
                        tvx = (dx / dn) * self.pulse_linear_speed
                        tvy = (dy / dn) * self.pulse_linear_speed
                        ct, st = math.cos(self.current_pose.theta), math.sin(self.current_pose.theta)
                        cmd.linear.x = tvx * ct + tvy * st
                        if abs(alpha) > self.angle_tolerance:
                            cmd.angular.z = np.sign(alpha) * min(self.pulse_angular_speed, abs(alpha))
                else:
                    cmd = Twist()
            else:
                self.get_logger().info('✅ Pulse control complete → FINAL_ADJUSTMENT (rotate-only)')
                self.state = ControllerState.FINAL_ADJUSTMENT
                self.pulse_cycle_start_time = None
                self._lin_pulse_t0 = None
                self._reach_since = None
                self.fa_pulse_t0 = None
                self.re_phase = 'ROTATE'

        elif self.state == ControllerState.FINAL_ADJUSTMENT:
            # ★ 회전만: target_yaw에 맞출 때까지 각도 펄스만 출력
            yaw_err = self.shortest_ang_dist(self.current_pose.theta, self.target_yaw)

            if abs(yaw_err) > self.angle_tolerance:
                # rotate-only (no linear)
                if abs(yaw_err) <= self.fa_ang_deadband:
                    cmd = Twist()
                else:
                    if self.fa_ang_pulse_active(now):
                        cmd.angular.z = math.copysign(min(self.fa_ang_speed, self.max_angular_vel), yaw_err)
                        cmd.linear.x = 0.0
                    else:
                        cmd = Twist()
                self._reach_since = None
            else:
                # yaw 정렬 완료
                if dist > self.position_tolerance:
                    # ★ 거리가 여전히 크면, REAPPROACH(미니 루프)로 전환
                    self.get_logger().info('➡️ Yaw OK but too far → REAPPROACH (mini loop: ROTATE→STEP)')
                    self.state = ControllerState.REAPPROACH
                    self.re_phase = 'ROTATE'
                    self.angular_pid.reset()
                    self.linear_pid.reset()
                    self.fa_pulse_t0 = None
                    self._lin_pulse_t0 = None
                    self._planned_reverse = False
                    cmd = Twist()
                else:
                    # yaw, dist 모두 만족 → hold
                    if self._reach_since is None:
                        self._reach_since = now
                    if now - self._reach_since >= self.reach_hold_time:
                        self._log_event('REACHED', self.state.name, 'REACHED')
                        self.get_logger().info('🎉 TARGET REACHED SUCCESSFULLY!')
                        self.get_logger().info(
                            f'📍 Final pos=({self.current_pose.x:.4f},{self.current_pose.y:.4f}) '
                            f'| yaw={math.degrees(self.current_pose.theta):.1f}°'
                        )
                        self.get_logger().info(f'📏 Pos err={dist:.4f} m')
                        self.state = ControllerState.REACHED
                        self.stop_robot()
                        return
                    else:
                        cmd = Twist()

        elif self.state == ControllerState.REAPPROACH:
            # ★ 미니 루프: (1) 덜 도는 방향으로 ROTATE → (2) 그 방향으로 한 펄스 STEP → 반복
            dx, dy = self.target_x - self.current_pose.x, self.target_y - self.current_pose.y
            dist = math.hypot(dx, dy)
            bearing = math.atan2(dy, dx)                  # 목표점 베어링

            # 전/후 후보의 회전량 비교
            yaw_fwd = self.wrap_angle(bearing)            # 전진 헤딩
            yaw_rev = self.wrap_angle(bearing + math.pi)  # 후진 헤딩
            alpha_fwd = self.shortest_ang_dist(self.current_pose.theta, yaw_fwd)
            alpha_rev = self.shortest_ang_dist(self.current_pose.theta, yaw_rev)

            use_reverse = abs(alpha_rev) < abs(alpha_fwd)
            yaw_set = yaw_rev if use_reverse else yaw_fwd
            alpha_to_set = self.shortest_ang_dist(self.current_pose.theta, yaw_set)

            # 상태 표시용
            self._planned_reverse = use_reverse

            # 도착 판정
            if dist <= self.position_tolerance:
                self.get_logger().info('🎯 Close enough → FINAL_ADJUSTMENT (yaw touch-up)')
                self.state = ControllerState.FINAL_ADJUSTMENT
                self.re_phase = 'ROTATE'
                self.fa_pulse_t0 = None
                self._lin_pulse_t0 = None
                self._reach_since = None
                cmd = Twist()
            else:
                if self.re_phase == 'ROTATE':
                    # 각도 먼저 맞추기 (짧게 도는 쪽 선택)
                    if abs(alpha_to_set) > self.step_ang_tol:
                        if abs(alpha_to_set) > self.step_ang_deadband and self.fa_ang_pulse_active(now):
                            cmd.angular.z = math.copysign(min(self.fa_ang_speed, self.max_angular_vel), alpha_to_set)
                            cmd.linear.x = 0.0
                        else:
                            cmd = Twist()
                        # 회전 중에는 선형 펄스 타이머 초기화(다음 STEP 깔끔하게 시작)
                        self._lin_pulse_t0 = None
                    else:
                        # 각이 맞춰졌으면, 다음 루프부터 한 번 'STEP'
                        self.re_phase = 'STEP'
                        self._lin_pulse_t0 = None
                        self.fa_pulse_t0 = None  # 다음 회전을 위해 리셋
                        cmd = Twist()

                elif self.re_phase == 'STEP':
                    # STEP 도중 yaw 드리프트 크면 즉시 ROTATE로 복귀
                    yaw_err_now = self.shortest_ang_dist(self.current_pose.theta, yaw_set)
                    if abs(yaw_err_now) > self.yaw_lock_exit:
                        self.re_phase = 'ROTATE'
                        self.fa_pulse_t0 = None
                        cmd = Twist()
                    else:
                        # 한 펄스만
                        v = self.final_lin_pulse_speed
                        if self._lin_pulse_active(now):
                            cmd.linear.x = -v if use_reverse else +v
                            cmd.angular.z = 0.0
                        else:
                            # 펄스 끝 → 다시 ROTATE
                            self.re_phase = 'ROTATE'
                            self.fa_pulse_t0 = None
                            cmd = Twist()

        elif self.state == ControllerState.REACHED:
            cmd = Twist()

        elif self.state == ControllerState.ERROR or self.state == ControllerState.PAUSED:
            self.stop_robot()
            return

        # publish & log
        self.cmd_vel_pub.publish(cmd)
        self.data.add_sample(now, self.current_pose, self.target_x, self.target_y,
                             alpha, cmd, self.state, self.linear_pid, self.angular_pid,
                             self._planned_reverse)

        # --- detect & record state transitions (after deciding self.state) ---
        if self.state != self._last_state:
            dist_now = dist
            to_target_now = self.current_pose.angle_to(self.target_x, self.target_y)
            ang_err_now = self.wrap_angle(to_target_now - self.current_pose.theta)
            self._events.append({
                't': now,
                'type': 'STATE_CHANGE',
                'from': self._last_state.name,
                'to': self.state.name,
                'x': self.current_pose.x,
                'y': self.current_pose.y,
                'theta': self.current_pose.theta,
                'dist': dist_now,
                'ang_err': ang_err_now
            })
            self._last_state = self.state

    # ----------------- helpers -----------------

    def stop_robot(self):
        self.cmd_vel_pub.publish(Twist())

    def print_status(self):
        if not self.odom_received:
            self.get_logger().warn('⏳ Waiting for odometry...')
            return
        dist = self.current_pose.distance_to(self.target_x, self.target_y)
        to_target = self.current_pose.angle_to(self.target_x, self.target_y)
        ang_err = self.wrap_angle(to_target - self.current_pose.theta)
        self.get_logger().info(
            f'🤖 {self.state.name} | Pos=({self.current_pose.x:.3f},{self.current_pose.y:.3f}) '
            f'| Dist={dist:.3f}m | AngErr={math.degrees(ang_err):.1f}° '
            f'| REAPP={"REV" if self._planned_reverse else "FWD"} | phase={self.re_phase}'
        )

    # ----------------- exports & metrics -----------------

    def _resample_indices(self, ts: np.ndarray, dt: float) -> np.ndarray:
        if ts.size == 0:
            return np.array([], dtype=int)
        t0, tN = ts[0], ts[-1]
        grid = np.arange(t0, tN + 1e-9, dt)
        idx = np.searchsorted(ts, grid, side='left')
        idx[idx == ts.size] = ts.size - 1
        return np.unique(idx)

    def export_timeseries_csv(self, path_csv: str, sample_dt: float = 0.1):
        import csv
        arr = self.data.get_arrays()
        ts = arr['timestamps']
        if ts.size == 0:
            self.get_logger().warn('No timeseries to export.')
            return
        idx = self._resample_indices(ts, sample_dt)

        with open(path_csv, 'w', newline='') as f:
            w = csv.writer(f)
            w.writerow(['t','x','y','theta','vx','omega','dist_to_goal','ang_err',
                        'cmd_lin','cmd_ang','state_id','state_name','planned_reverse',
                        'linP','linI','linD','angP','angI','angD',
                        'target_x','target_y','target_yaw'])
            for i in idx:
                t = float(ts[i])
                x = float(arr['position_x'][i])
                y = float(arr['position_y'][i])
                theta = float(arr['theta'][i])
                vx = float(arr['vx'][i])
                omega = float(arr['omega'][i])
                dist = float(arr['distance_to_target'][i])
                ang_err = float(arr['angular_error'][i])
                cmd_lin = float(arr['linear_velocity_cmd'][i])
                cmd_ang = float(arr['angular_velocity_cmd'][i])
                state_val = int(arr['controller_state'][i])
                try:
                    state_name = ControllerState(state_val).name
                except Exception:
                    state_name = str(state_val)
                prev_flag = int(arr['planned_reverse'][i])
                w.writerow([t,x,y,theta,vx,omega,dist,ang_err,
                            cmd_lin,cmd_ang,state_val,state_name,prev_flag,
                            float(arr['linear_pid_p'][i]), float(arr['linear_pid_i'][i]), float(arr['linear_pid_d'][i]),
                            float(arr['angular_pid_p'][i]), float(arr['angular_pid_i'][i]), float(arr['angular_pid_d'][i]),
                            self.target_x, self.target_y, self.target_yaw])

    def export_events_csv(self, path_csv: str):
        import csv
        with open(path_csv, 'w', newline='') as f:
            w = csv.writer(f)
            w.writerow(['t','event','from_state','to_state','x','y','theta','dist','ang_err'])
            for e in self._events:
                w.writerow([e['t'], e['type'], e['from'], e['to'], e['x'], e['y'], e['theta'], e['dist'], e['ang_err']])

    def compute_summary(self) -> Dict[str, float]:
        arr = self.data.get_arrays()
        ts = arr['timestamps']
        if ts.size == 0:
            return {}
        pos_err = arr['distance_to_target']
        ang_err = arr['angular_error']
        x = arr['position_x']; y = arr['position_y']
        # path length
        if x.size >= 2:
            dx = np.diff(x); dy = np.diff(y)
            dist_traveled = float(np.sum(np.hypot(dx, dy)))
        else:
            dist_traveled = 0.0
        rms_pos = float(np.sqrt(np.mean(pos_err**2))) if pos_err.size else 0.0
        rms_ang = float(np.sqrt(np.mean(ang_err**2))) if ang_err.size else 0.0
        max_pos = float(np.max(pos_err)) if pos_err.size else 0.0
        max_ang = float(np.max(np.abs(ang_err))) if ang_err.size else 0.0
        # oscillations: sign changes in angular error
        s = np.sign(ang_err)
        osc = int(np.sum((s[1:] * s[:-1]) < 0)) if s.size >= 2 else 0

        peak_cmd_lin = float(np.max(np.abs(arr['linear_velocity_cmd']))) if arr['linear_velocity_cmd'].size else 0.0
        peak_cmd_ang = float(np.max(np.abs(arr['angular_velocity_cmd']))) if arr['angular_velocity_cmd'].size else 0.0

        return {
            'start_time': float(ts[0]),
            'end_time': float(ts[-1]),
            'total_time': float(ts[-1] - ts[0]),
            'max_pos_err': max_pos,
            'max_ang_err_deg': math.degrees(max_ang),
            'rms_pos_err': rms_pos,
            'rms_ang_err_deg': math.degrees(rms_ang),
            'oscillations': osc,
            'distance_traveled': dist_traveled,
            'peak_cmd_lin': peak_cmd_lin,
            'peak_cmd_ang': peak_cmd_ang,
        }

    def append_summary_csv(self, path_csv: str, trial_meta: Dict[str, float]):
        import csv, os
        summary = self.compute_summary()
        if not summary:
            self.get_logger().warn('No summary computed.')
            return
        row = {**trial_meta, **summary}
        headers = ['trial_id',
                   'start_x','start_y','start_yaw',
                   'goal_x','goal_y','goal_yaw',
                   'start_time','end_time','total_time',
                   'max_pos_err','max_ang_err_deg',
                   'rms_pos_err','rms_ang_err_deg',
                   'oscillations','distance_traveled',
                   'peak_cmd_lin','peak_cmd_ang']
        file_exists = os.path.exists(path_csv)
        with open(path_csv, 'a', newline='') as f:
            w = csv.DictWriter(f, fieldnames=headers)
            if not file_exists:
                w.writeheader()
            for k in headers:
                if k not in row:
                    row[k] = 0.0
            w.writerow(row)


# (선택) 단독 실행용 엔트리
def main(args=None):
    import sys
    rclpy.init(args=args if args is not None else sys.argv)
    node = AdvancedPositionController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('🛑 KeyboardInterrupt: shutting down...')
    finally:
        try:
            node.stop_robot()
        except Exception:
            pass
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()