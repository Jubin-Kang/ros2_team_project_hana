# ================================
# File: run_trials_batch.py
# ================================

#!/usr/bin/env python3
"""
Batch runner for multiple sequential trials.
- Assumes run_trial.py is in the same directory (or provide --run_script path)
- Runs trial IDs from --start_n to --end_n (inclusive), e.g., 003..010
- Passes goal/round_trip/etc. to each run

Example:
  python3 run_trials_batch.py \
    --start_n 3 --end_n 10 \
    --goal_x 0.24 --goal_y -0.23 --goal_yaw_deg 90 \
    --round_trip \
    --log_dir logs --sleep_s 2
"""

import argparse
import subprocess
import sys
import time
from pathlib import Path


def parse_args():
    p = argparse.ArgumentParser()
    # range
    p.add_argument('--start_n', type=int, default=3)
    p.add_argument('--end_n', type=int, default=10)

    # run_trial location
    p.add_argument('--python_exec', type=str, default=sys.executable)
    p.add_argument('--run_script', type=str, default='run_trial.py')

    # common args forwarded to each run
    p.add_argument('--trial_prefix', type=str, default='trial_')
    p.add_argument('--log_dir', type=str, default='logs')
    p.add_argument('--goal_x', type=float, required=True)
    p.add_argument('--goal_y', type=float, required=True)
    p.add_argument('--goal_yaw_deg', type=float, default=0.0)
    p.add_argument('--timeout_s', type=float, default=120.0)
    p.add_argument('--sample_dt', type=float, default=0.1)

    # round-trip options
    p.add_argument('--round_trip', action='store_true')
    p.add_argument('--return_x', type=float, default=None)
    p.add_argument('--return_y', type=float, default=None)
    p.add_argument('--return_yaw_deg', type=float, default=None)

    # runner behavior
    p.add_argument('--sleep_s', type=float, default=2.0, help='sleep between trials')
    p.add_argument('--stop_on_error', action='store_true', help='stop batch if a run exits nonzero')

    return p.parse_args()


def build_cmd(a, i: int) -> list:
    trial_id = f"{a.trial_prefix}{i:03d}"
    cmd = [
        a.python_exec,
        a.run_script,
        '--trial_id', trial_id,
        '--log_dir', a.log_dir,
        '--goal_x', str(a.goal_x),
        '--goal_y', str(a.goal_y),
        '--goal_yaw_deg', str(a.goal_yaw_deg),
        '--timeout_s', str(a.timeout_s),
        '--sample_dt', str(a.sample_dt),
    ]
    if a.round_trip:
        cmd.append('--round_trip')
    if a.return_x is not None and a.return_y is not None:
        cmd += ['--return_x', str(a.return_x), '--return_y', str(a.return_y)]
        if a.return_yaw_deg is not None:
            cmd += ['--return_yaw_deg', str(a.return_yaw_deg)]
    return cmd


def main():
    a = parse_args()

    # Validate script path
    script_path = Path(a.run_script)
    if not script_path.exists():
        print(f"[ERROR] run_script not found: {script_path.resolve()}")
        sys.exit(1)

    print(f"[BATCH] Running trials {a.start_n:03d}..{a.end_n:03d}")

    for i in range(a.start_n, a.end_n + 1):
        cmd = build_cmd(a, i)
        print('' + '='*72)
        print(f"[BATCH] Starting trial {i:03d}: {' '.join(cmd)}")
        print('='*72)
        proc = subprocess.run(cmd)
        if proc.returncode != 0:
            print(f"[BATCH][ERROR] Trial {i:03d} exited with code {proc.returncode}")
            if a.stop_on_error:
                print("[BATCH] stop_on_error set → stopping batch")
                sys.exit(proc.returncode)
        else:
            print(f"[BATCH] Trial {i:03d} completed successfully")
        time.sleep(a.sleep_s)

    print("[BATCH] All requested trials finished.")


if __name__ == '__main__':
    main()
