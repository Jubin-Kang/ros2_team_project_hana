# ================================
# File: run_trial.py
# ================================

#!/usr/bin/env python3
import os
import math
import time
import argparse
from datetime import datetime

import rclpy
from rclpy.executors import MultiThreadedExecutor

# 같은 디렉토리에 있다고 가정
from advanced_position_controller import (
    AdvancedPositionController,
    ControllerState,
    DataCollector,
)


def wait_for_odom(node: AdvancedPositionController, timeout_s: float = 5.0):
    """odom 수신 대기 (초기 포즈 캡처용)."""
    execu = MultiThreadedExecutor()
    execu.add_node(node)
    t0 = time.time()
    try:
        while rclpy.ok() and (time.time() - t0) < timeout_s:
            execu.spin_once(timeout_sec=0.05)
            if node.odom_received:
                return execu
        raise TimeoutError("No odom received within timeout.")
    except KeyboardInterrupt:
        raise


def run_leg(
    node: AdvancedPositionController,
    execu: MultiThreadedExecutor,
    trial_id: str,
    leg_name: str,
    goal_x: float,
    goal_y: float,
    goal_yaw_deg: float,
    log_dir: str,
    sample_dt: float,
    timeout_s: float,
    ts_tag: str,
    start_pose_tuple,
):
    """한 구간(leg) 실행 및 CSV 3종 저장."""
    # 시작 포즈 기록
    sx, sy, syaw = start_pose_tuple

    # 목표 설정 (즉시 시작)
    node.set_target(goal_x, goal_y, math.radians(goal_yaw_deg))

    t0 = time.time()
    while rclpy.ok():
        execu.spin_once(timeout_sec=0.05)
        if node.state == ControllerState.REACHED:
            node.get_logger().info(f'🏁 Leg {leg_name} finished: REACHED')
            break
        if node.state == ControllerState.ERROR:
            node.get_logger().error(f'❌ Leg {leg_name} aborted: ERROR state')
            break
        if (time.time() - t0) > timeout_s:
            node.get_logger().error(f'⏰ Leg {leg_name} timeout reached.')
            node.state = ControllerState.ERROR
            break

    # 파일 경로 구성
    os.makedirs(log_dir, exist_ok=True)
    base = f"{trial_id}_{ts_tag}_{leg_name}"
    timeseries_csv = os.path.join(log_dir, f"{base}_timeseries_10hz.csv")
    events_csv = os.path.join(log_dir, f"{base}_events.csv")
    summary_csv = os.path.join(log_dir, "trials_summary.csv")  # append

    # 내보내기
    node.export_timeseries_csv(timeseries_csv, sample_dt=sample_dt)
    node.export_events_csv(events_csv)

    trial_meta = {
        'trial_id': f"{trial_id}_{leg_name}",
        'start_x': float(sx),
        'start_y': float(sy),
        'start_yaw': float(syaw),
        'goal_x': float(goal_x),
        'goal_y': float(goal_y),
        'goal_yaw': math.radians(float(goal_yaw_deg)),
    }
    node.append_summary_csv(summary_csv, trial_meta)

    node.get_logger().info(f'📝 Saved: {timeseries_csv}')
    node.get_logger().info(f'📝 Saved: {events_csv}')
    node.get_logger().info(f'📝 Appended: {summary_csv}')

    # 다음 leg 대비 로그 초기화
    node.data = DataCollector()
    node._events = []



def main():
    p = argparse.ArgumentParser()
    p.add_argument('--trial_id', type=str, default='trial_001')
    p.add_argument('--log_dir', type=str, default='logs')
    p.add_argument('--goal_x', type=float, required=True)
    p.add_argument('--goal_y', type=float, required=True)
    p.add_argument('--goal_yaw_deg', type=float, default=0.0)
    p.add_argument('--timeout_s', type=float, default=120.0)
    p.add_argument('--sample_dt', type=float, default=0.1)

    # 왕복 옵션
    p.add_argument('--round_trip', action='store_true', help='목표 지점 도달 후 복귀 실행')
    p.add_argument('--return_x', type=float, default=None)
    p.add_argument('--return_y', type=float, default=None)
    p.add_argument('--return_yaw_deg', type=float, default=None)

    args = p.parse_args()

    rclpy.init()
    node = AdvancedPositionController()

    # 시작 즉시 — 대기 없이 실행. (단, odom은 받아야 하므로 첫 odom을 기다림)
    execu = wait_for_odom(node, timeout_s=5.0)

    # 최초 odom으로 Start 포즈 스냅샷
    start_pose = (node.current_pose.x, node.current_pose.y, node.current_pose.theta)
    node.get_logger().info(
        f"📌 Start snapshot: ({start_pose[0]:.3f}, {start_pose[1]:.3f}), yaw={math.degrees(start_pose[2]):.1f}°"
    )

    ts_tag = datetime.now().strftime('%Y%m%d_%H%M%S')

    # Leg A: 현재 위치 → 목표
    run_leg(
        node=node,
        execu=execu,
        trial_id=args.trial_id,
        leg_name='A',
        goal_x=args.goal_x,
        goal_y=args.goal_y,
        goal_yaw_deg=args.goal_yaw_deg,
        log_dir=args.log_dir,
        sample_dt=args.sample_dt,
        timeout_s=args.timeout_s,
        ts_tag=ts_tag,
        start_pose_tuple=start_pose,
    )

    # Round-trip이면 복귀 실행
    if args.round_trip:
        # 복귀 목표 결정: 명시되었으면 사용, 아니면 start snapshot으로 복귀
        if args.return_x is not None and args.return_y is not None:
            rx = args.return_x
            ry = args.return_y
            ryaw_deg = args.return_yaw_deg if args.return_yaw_deg is not None else math.degrees(start_pose[2])
        else:
            rx, ry, ryaw = start_pose
            ryaw_deg = math.degrees(ryaw)

        # 복귀 leg 시작 시점의 현재 포즈를 새 start로 기록
        start_pose_B = (node.current_pose.x, node.current_pose.y, node.current_pose.theta)
        run_leg(
            node=node,
            execu=execu,
            trial_id=args.trial_id,
            leg_name='B',
            goal_x=rx,
            goal_y=ry,
            goal_yaw_deg=ryaw_deg,
            log_dir=args.log_dir,
            sample_dt=args.sample_dt,
            timeout_s=args.timeout_s,
            ts_tag=ts_tag,
            start_pose_tuple=start_pose_B,
        )

    # 종료
    try:
        node.stop_robot()
    except Exception:
        pass
    execu.shutdown()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()